<?php
/**
 * The index.php file for the css directory
 *
 * @package miniorange-saml-20-single-sign-on\includes\css
 */
