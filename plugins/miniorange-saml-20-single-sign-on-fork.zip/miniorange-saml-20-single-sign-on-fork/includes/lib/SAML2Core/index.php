<?php
/**
 * The index.php file for the SAML2Core library directory
 *
 * @package miniorange-saml-20-single-sign-on\includes\lib\SAML2Core
 */
