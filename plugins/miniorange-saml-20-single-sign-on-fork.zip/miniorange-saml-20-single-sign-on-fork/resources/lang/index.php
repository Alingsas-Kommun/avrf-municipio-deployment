<?php
/**
 * The index.php file for the lang directory
 *
 * @package miniorange-saml-20-single-sign-on\resources\lang
 */
