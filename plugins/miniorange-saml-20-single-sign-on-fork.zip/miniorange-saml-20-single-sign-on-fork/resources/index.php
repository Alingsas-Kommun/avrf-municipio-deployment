<?php
/**
 * The index.php file for the resources directory
 *
 * @package miniorange-saml-20-single-sign-on\resources
 */
