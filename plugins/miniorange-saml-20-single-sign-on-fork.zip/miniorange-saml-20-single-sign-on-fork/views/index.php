<?php
/**
 * The index.php file for the views directory
 *
 * @package miniorange-saml-20-single-sign-on\views
 */
